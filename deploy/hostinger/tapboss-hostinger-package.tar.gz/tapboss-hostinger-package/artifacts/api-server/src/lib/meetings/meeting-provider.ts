export interface MeetingProvider {
  readonly key: string;
  generateRoomUrl(meetingId: string): string;
  generateMeetingId(context: MeetingContext): string;
  createRoom(context: MeetingContext): CreateMeetingRoomResult;
}

export interface MeetingContext {
  companySlug: string;
  department?: string | null;
  project?: string | null;
  date: Date;
  displayName?: string | null;
  email?: string | null;
  avatarUrl?: string | null;
  userId?: string | number | null;
}

export interface CreateMeetingRoomResult {
  roomUrl: string;
  meetingId: string;
  jwt?: string;
}
